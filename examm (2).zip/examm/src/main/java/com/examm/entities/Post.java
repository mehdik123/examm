package com.examm.entities;

public enum Post {
    MANAGER, DEV, TEST, DEVOPS, TECHLEAD
}